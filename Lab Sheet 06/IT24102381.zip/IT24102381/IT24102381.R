setwd("C:\\Users\\yuthi\\Desktop\\IT24102381")

#01

#i)
#Binomial Distribution
#n=50  , p = 0.85

#ii)
pbinom(46, 50, 0.85, lower.tail = FALSE)



#02

#i)
# number of calls received in one hour

#ii)
#Poisson Distribution

#iii)
dpois(15, 12)


